import { supabaseServer } from "@/lib/supabase/server";

export default async function DashboardPage() {
  const supabase = await supabaseServer();
  const { data } = await supabase.auth.getUser();
  const user = data.user!;

  const { data: profile, error } = await supabase
    .from("user_profiles")
    .select("full_name, role, tenant_id")
    .eq("user_id", user.id)
    .single();

  return (
    <main className="p-6 max-w-3xl mx-auto">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Dashboard</h1>

        <form action="/auth/sign-out" method="post">
          <button className="rounded-xl border px-3 py-2">Logout</button>
        </form>
      </div>

      <div className="mt-6 rounded-2xl border p-4">
        <p className="text-sm text-gray-500">Eingeloggt als</p>
        <p className="text-lg font-medium">
          {profile?.full_name ?? user.email}
        </p>

        <div className="mt-2 text-sm">
          <div>
            Rolle: <b>{profile?.role ?? "?"}</b>
          </div>
          <div>
            Tenant: <b>{profile?.tenant_id ?? "ADMIN (alle)"}</b>
          </div>
        </div>

        {error && (
          <div className="mt-3 text-sm text-red-600">
            Profil-Fehler: {error.message}
          </div>
        )}
      </div>

      <div className="mt-6 text-sm text-gray-500">
        Nächster Schritt: Tenants anlegen + Behandler-Accounts hinzufügen.
      </div>

      <div className="mt-6 flex gap-3">
        <a className="rounded-xl border px-3 py-2" href="/customers">
          Kunden
        </a>
      </div>
    </main>
  );
}