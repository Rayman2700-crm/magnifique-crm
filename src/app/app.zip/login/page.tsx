import { redirect } from "next/navigation";
import { supabaseServer } from "@/lib/supabase/server";

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ next?: string; error?: string; msg?: string }>;
}) {
  const supabase = await supabaseServer();
  const { data } = await supabase.auth.getUser();

  if (data.user) redirect("/dashboard");

  const sp = await searchParams;
  const next = sp.next ?? "/dashboard";
  const hasError = sp.error === "1";
  const msg = sp.msg ?? "";

  return (
    <main className="min-h-screen flex items-center justify-center p-6">
      <div className="w-full max-w-md rounded-2xl border p-6 shadow-sm">
        <h1 className="text-2xl font-semibold">Magnifique CRM</h1>
        <p className="text-sm text-gray-500 mt-1">
          Bitte einloggen, um fortzufahren.
        </p>

        {hasError && (
          <div className="mt-4 rounded-xl border border-red-300 bg-red-50 p-3 text-sm text-red-700">
            Login fehlgeschlagen: {msg || "Bitte E-Mail/Passwort prüfen."}
          </div>
        )}

        <form action="/auth/sign-in" method="post" className="mt-6 space-y-4">
          <input type="hidden" name="next" value={next} />

          <div>
            <label className="text-sm font-medium">E-Mail</label>
            <input
              name="email"
              type="email"
              required
              className="mt-1 w-full rounded-xl border px-3 py-2"
              placeholder="name@email.com"
            />
          </div>

          <div>
            <label className="text-sm font-medium">Passwort</label>
            <input
              name="password"
              type="password"
              required
              className="mt-1 w-full rounded-xl border px-3 py-2"
              placeholder="••••••••"
            />
          </div>

          <button
            type="submit"
            className="w-full rounded-xl bg-black text-white py-2 font-medium"
          >
            Einloggen
          </button>
        </form>
      </div>
    </main>
  );
}