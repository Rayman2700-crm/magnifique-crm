import Link from "next/link";
import { createCustomer } from "./actions";
import { supabaseServer } from "@/lib/supabase/server";

export default async function NewCustomerPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; details?: string }>;
}) {
  const supabase = await supabaseServer();
  const { data } = await supabase.auth.getUser();
  if (!data.user) {
    // middleware macht das eh, aber doppelt ist ok
  }

  const sp = await searchParams;

  return (
    <main className="p-6 max-w-2xl mx-auto">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Neuer Kunde</h1>
        <Link className="rounded-xl border px-3 py-2" href="/customers">
          Zurück
        </Link>
      </div>

      {sp.error && (
        <div className="mt-4 rounded-xl border border-red-300 bg-red-50 p-3 text-sm text-red-700">
          {decodeURIComponent(sp.error)}
        </div>
      )}

      {sp.details && (
        <div className="mt-2 text-xs text-gray-500">
          Details: {decodeURIComponent(sp.details)}
        </div>
      )}

      <form action={createCustomer} className="mt-6 space-y-4">
        <div>
          <label className="text-sm font-medium">Name *</label>
          <input
            name="full_name"
            required
            className="mt-1 w-full rounded-xl border px-3 py-2"
            placeholder="Vorname Nachname"
          />
        </div>

        <div>
          <label className="text-sm font-medium">Telefon</label>
          <input
            name="phone"
            className="mt-1 w-full rounded-xl border px-3 py-2"
            placeholder="+43..."
          />
        </div>

        <div>
          <label className="text-sm font-medium">E-Mail</label>
          <input
            name="email"
            type="email"
            className="mt-1 w-full rounded-xl border px-3 py-2"
            placeholder="kunde@email.com"
          />
        </div>

        <div>
          <label className="text-sm font-medium">Geburtsdatum</label>
          <input
            name="birthday"
            type="date"
            className="mt-1 w-full rounded-xl border px-3 py-2"
          />
        </div>

        <button className="rounded-xl bg-black text-white px-4 py-2">
          Speichern
        </button>
      </form>

      <p className="mt-6 text-xs text-gray-500">
        Hinweis: Person ist tenant-übergreifend, aber das Kundenprofil wird pro
        Behandler erstellt.
      </p>
    </main>
  );
}