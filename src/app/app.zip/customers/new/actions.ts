"use server";

import { redirect } from "next/navigation";
import { supabaseServer } from "@/lib/supabase/server";

function normalizeEmail(v: string) {
  return v.trim().toLowerCase();
}
function normalizePhone(v: string) {
  return v.replace(/\s+/g, "").trim();
}

export async function createCustomer(formData: FormData) {
  const fullName = String(formData.get("full_name") ?? "").trim();
  const emailRaw = String(formData.get("email") ?? "").trim();
  const phoneRaw = String(formData.get("phone") ?? "").trim();
  const birthdayRaw = String(formData.get("birthday") ?? "").trim(); // YYYY-MM-DD oder leer

  if (!fullName) {
    redirect("/customers/new?error=Bitte%20Name%20eingeben");
  }

  const email = emailRaw ? normalizeEmail(emailRaw) : null;
  const phone = phoneRaw ? normalizePhone(phoneRaw) : null;

  const supabase = await supabaseServer();

  // 1) Current user + tenant laden
  const { data: userData } = await supabase.auth.getUser();
  const user = userData.user;
  if (!user) redirect("/login");

  const { data: profile, error: profileError } = await supabase
    .from("user_profiles")
    .select("tenant_id, role")
    .eq("user_id", user.id)
    .single();

  if (profileError || !profile) {
    redirect("/customers/new?error=Kein%20Profil%20gefunden");
  }

  // Admin darf später Tenant auswählen – fürs Erste: Admin ohne tenant kann keinen Kunden anlegen
  if (!profile.tenant_id) {
    redirect("/customers/new?error=Admin%20bitte%20sp%C3%A4ter%20Tenant%20w%C3%A4hlen");
  }

  const tenantId = profile.tenant_id;

  // 2) Person finden (Dublettencheck): bevorzugt email, sonst phone
  let personId: string | null = null;

  if (email) {
    const { data: existing } = await supabase
      .from("persons")
      .select("id")
      .eq("email", email)
      .maybeSingle();
    personId = existing?.id ?? null;
  }

  if (!personId && phone) {
    const { data: existing } = await supabase
      .from("persons")
      .select("id")
      .eq("phone", phone)
      .maybeSingle();
    personId = existing?.id ?? null;
  }

  // 3) Person anlegen, wenn nicht vorhanden
  if (!personId) {
    const { data: inserted, error } = await supabase
      .from("persons")
      .insert({
        full_name: fullName,
        email,
        phone,
        birthday: birthdayRaw || null,
      })
      .select("id")
      .single();

    if (error || !inserted) {
      redirect("/customers/new?error=Person%20konnte%20nicht%20erstellt%20werden");
    }
    personId = inserted.id;
  } else {
    // Optional: Daten updaten, falls neue Infos geliefert wurden
    await supabase
      .from("persons")
      .update({
        full_name: fullName,
        email,
        phone,
        birthday: birthdayRaw || null,
      })
      .eq("id", personId);
  }

  // 4) CustomerProfile für diesen Tenant anlegen (falls noch nicht)
  const { data: existingProfile } = await supabase
    .from("customer_profiles")
    .select("id")
    .eq("tenant_id", tenantId)
    .eq("person_id", personId)
    .maybeSingle();

  if (!existingProfile) {
    const { error } = await supabase.from("customer_profiles").insert({
      tenant_id: tenantId,
      person_id: personId,
    });

    if (error) {
      const msg = encodeURIComponent(error?.message ?? "unknown");
      redirect(`/customers/new?error=Person%20konnte%20nicht%20erstellt%20werden&details=${msg}`);
    }
  }

  redirect("/customers");
}