import Link from "next/link";
import { supabaseServer } from "@/lib/supabase/server";

export default async function CustomersPage() {
  const supabase = await supabaseServer();
  const { data: userData } = await supabase.auth.getUser();
  const user = userData.user!;

  const { data: profile } = await supabase
    .from("user_profiles")
    .select("role, tenant_id, full_name")
    .eq("user_id", user.id)
    .single();

  // Kundenliste (tenant-scope via RLS)
  // Wir holen customer_profiles + person Daten
  const { data: rows, error } = await supabase
    .from("customer_profiles")
    .select(
      `
      id,
      created_at,
      person_id,
      person:persons (
        id,
        full_name,
        phone,
        email,
        birthday
      )
    `
    )
    .order("created_at", { ascending: false })
    .limit(50);

  return (
    <main className="p-6 max-w-5xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Kunden</h1>
          <p className="text-sm text-gray-500">
            Eingeloggt als {profile?.full_name} ({profile?.role})
          </p>
        </div>

        <Link
          className="rounded-xl bg-black text-white px-4 py-2"
          href="/customers/new"
        >
          + Neuer Kunde
        </Link>
      </div>

      {error && (
        <div className="mt-4 rounded-xl border border-red-300 bg-red-50 p-3 text-sm text-red-700">
          Fehler: {error.message}
        </div>
      )}

      <div className="mt-6 rounded-2xl border overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-50">
            <tr className="text-left">
              <th className="p-3">Name</th>
              <th className="p-3">Telefon</th>
              <th className="p-3">E-Mail</th>
              <th className="p-3">Erstellt</th>
            </tr>
          </thead>
          <tbody>
            {(rows ?? []).map((r: any) => (
              <tr key={r.id} className="border-t">
                <td className="p-3 font-medium">
                  <Link className="underline" href={`/customers/${r.id}`}>
                    {r.person?.full_name ?? "-"}
                  </Link>
                </td>
                <td className="p-3">{r.person?.phone ?? "-"}</td>
                <td className="p-3">{r.person?.email ?? "-"}</td>
                <td className="p-3">
                  {r.created_at
                    ? new Date(r.created_at).toLocaleDateString()
                    : "-"}
                </td>
              </tr>
            ))}

            {(rows?.length ?? 0) === 0 && (
              <tr>
                <td className="p-6 text-gray-500" colSpan={4}>
                  Noch keine Kunden vorhanden.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </main>
  );
}