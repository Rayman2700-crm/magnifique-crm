"use server";

import { redirect } from "next/navigation";
import { supabaseServer } from "@/lib/supabase/server";

export async function addCustomerNote(
  customerProfileId: string,
  formData: FormData
) {
  const note = String(formData.get("note") ?? "").trim();
  if (!note) redirect(`/customers/${customerProfileId}`);

  const supabase = await supabaseServer();

  const { data: userData } = await supabase.auth.getUser();
  const user = userData.user;
  if (!user) redirect("/login");

  const { data: profile, error: profileError } = await supabase
    .from("user_profiles")
    .select("tenant_id, role")
    .eq("user_id", user.id)
    .single();

  if (profileError || !profile) {
    redirect(
      `/customers/${customerProfileId}?error=${encodeURIComponent(
        "Kein Benutzerprofil gefunden"
      )}`
    );
  }

  let tenantId: string | null = profile.tenant_id ?? null;

  // ADMIN: tenant_id vom customer_profiles nehmen
  if (profile.role === "ADMIN") {
    const { data: cp, error: cpError } = await supabase
      .from("customer_profiles")
      .select("tenant_id")
      .eq("id", customerProfileId)
      .single();

    if (cpError || !cp?.tenant_id) {
      redirect(
        `/customers/${customerProfileId}?error=${encodeURIComponent(
          "Konnte Tenant des Kunden nicht laden"
        )}`
      );
    }

    tenantId = cp.tenant_id;
  }

  if (!tenantId) {
    redirect(
      `/customers/${customerProfileId}?error=${encodeURIComponent(
        "Kein Tenant gefunden"
      )}`
    );
  }

  const { error: insertError } = await supabase.from("customer_notes").insert({
    customer_profile_id: customerProfileId,
    tenant_id: tenantId,
    created_by: user.id,
    note,
  });

  if (insertError) {
    redirect(
      `/customers/${customerProfileId}?error=${encodeURIComponent(
        `Notiz konnte nicht gespeichert werden: ${insertError.message}`
      )}`
    );
  }

  redirect(`/customers/${customerProfileId}`);
}

/**
 * MULTI Upload (neu) – wird von PhotoUpload.tsx verwendet
 * FormData key: "photos" (mehrere Files)
 */
export async function uploadCustomerPhotos(
  customerProfileId: string,
  formData: FormData
) {
  const supabase = await supabaseServer();

  const { data: userData } = await supabase.auth.getUser();
  const user = userData.user;
  if (!user) redirect("/login");

  const files = formData.getAll("photos") as File[];
  if (!files || files.length === 0) {
    redirect(
      `/customers/${customerProfileId}?error=${encodeURIComponent(
        "Keine Fotos gewählt"
      )}`
    );
  }

  const { data: profile, error: profileError } = await supabase
    .from("user_profiles")
    .select("tenant_id, role")
    .eq("user_id", user.id)
    .single();

  if (profileError || !profile) {
    redirect(
      `/customers/${customerProfileId}?error=${encodeURIComponent(
        "Kein Benutzerprofil gefunden"
      )}`
    );
  }

  // Tenant bestimmen:
  // Practitioner: eigener tenant_id
  // Admin: tenant vom Kundenprofil
  let tenantId: string | null = profile.tenant_id ?? null;

  if (profile.role === "ADMIN") {
    const { data: cp, error: cpError } = await supabase
      .from("customer_profiles")
      .select("tenant_id")
      .eq("id", customerProfileId)
      .single();

    if (cpError || !cp?.tenant_id) {
      redirect(
        `/customers/${customerProfileId}?error=${encodeURIComponent(
          "Konnte Tenant des Kunden nicht laden"
        )}`
      );
    }
    tenantId = cp.tenant_id;
  }

  if (!tenantId) {
    redirect(
      `/customers/${customerProfileId}?error=${encodeURIComponent(
        "Kein Tenant gefunden"
      )}`
    );
  }

  // Upload + DB Insert pro File (robust, mit Cleanup)
  for (const file of files) {
    const ext =
      file.name.split(".").pop()?.toLowerCase() ||
      (file.type === "image/png" ? "png" : "jpg");

    const objectName = `${tenantId}/${customerProfileId}/${crypto.randomUUID()}.${ext}`;

    const bytes = new Uint8Array(await file.arrayBuffer());

    const { error: upErr } = await supabase.storage
      .from("customer-photos")
      .upload(objectName, bytes, {
        contentType: file.type || "image/jpeg",
        upsert: false,
      });

    if (upErr) {
      redirect(
        `/customers/${customerProfileId}?error=${encodeURIComponent(
          `Upload fehlgeschlagen: ${upErr.message}`
        )}`
      );
    }

    const { error: dbErr } = await supabase.from("customer_photos").insert({
      customer_profile_id: customerProfileId,
      tenant_id: tenantId,
      created_by: user.id,
      storage_path: objectName,
      original_name: file.name,
      mime_type: file.type,
      size_bytes: file.size,
    });

    if (dbErr) {
      await supabase.storage.from("customer-photos").remove([objectName]);
      redirect(
        `/customers/${customerProfileId}?error=${encodeURIComponent(
          `DB-Insert fehlgeschlagen: ${dbErr.message}`
        )}`
      );
    }
  }

  redirect(`/customers/${customerProfileId}`);
}

/**
 * Single Upload (alt) – optional, wird aktuell NICHT mehr gebraucht.
 * Kann bleiben oder später gelöscht werden.
 */
export async function uploadCustomerPhoto(
  customerProfileId: string,
  formData: FormData
) {
  const supabase = await supabaseServer();

  const { data: userData } = await supabase.auth.getUser();
  const user = userData.user;
  if (!user) redirect("/login");

  const file = formData.get("photo") as File | null;
  if (!file) {
    redirect(
      `/customers/${customerProfileId}?error=${encodeURIComponent(
        "Kein Foto gewählt"
      )}`
    );
  }

  const { data: profile, error: profileError } = await supabase
    .from("user_profiles")
    .select("tenant_id, role")
    .eq("user_id", user.id)
    .single();

  if (profileError || !profile) {
    redirect(
      `/customers/${customerProfileId}?error=${encodeURIComponent(
        "Kein Benutzerprofil gefunden"
      )}`
    );
  }

  let tenantId: string | null = profile.tenant_id ?? null;

  if (profile.role === "ADMIN") {
    const { data: cp, error: cpError } = await supabase
      .from("customer_profiles")
      .select("tenant_id")
      .eq("id", customerProfileId)
      .single();

    if (cpError || !cp?.tenant_id) {
      redirect(
        `/customers/${customerProfileId}?error=${encodeURIComponent(
          "Konnte Tenant des Kunden nicht laden"
        )}`
      );
    }
    tenantId = cp.tenant_id;
  }

  if (!tenantId) {
    redirect(
      `/customers/${customerProfileId}?error=${encodeURIComponent(
        "Kein Tenant gefunden"
      )}`
    );
  }

  const ext =
    file.name.split(".").pop()?.toLowerCase() ||
    (file.type === "image/png" ? "png" : "jpg");

  const objectName = `${tenantId}/${customerProfileId}/${crypto.randomUUID()}.${ext}`;

  const bytes = new Uint8Array(await file.arrayBuffer());

  const { error: upErr } = await supabase.storage
    .from("customer-photos")
    .upload(objectName, bytes, {
      contentType: file.type || "image/jpeg",
      upsert: false,
    });

  if (upErr) {
    redirect(
      `/customers/${customerProfileId}?error=${encodeURIComponent(
        `Upload fehlgeschlagen: ${upErr.message}`
      )}`
    );
  }

  const { error: dbErr } = await supabase.from("customer_photos").insert({
    customer_profile_id: customerProfileId,
    tenant_id: tenantId,
    created_by: user.id,
    storage_path: objectName,
    original_name: file.name,
    mime_type: file.type,
    size_bytes: file.size,
  });

  if (dbErr) {
    await supabase.storage.from("customer-photos").remove([objectName]);
    redirect(
      `/customers/${customerProfileId}?error=${encodeURIComponent(
        `DB-Insert fehlgeschlagen: ${dbErr.message}`
      )}`
    );
  }

  redirect(`/customers/${customerProfileId}`);
}

export async function deleteCustomerPhoto(
  customerProfileId: string,
  photoId: string
) {
  const supabase = await supabaseServer();

  const { data: userData } = await supabase.auth.getUser();
  const user = userData.user;
  if (!user) redirect("/login");

  const { data: row, error } = await supabase
    .from("customer_photos")
    .select("id, storage_path")
    .eq("id", photoId)
    .single();

  if (error || !row) {
    redirect(
      `/customers/${customerProfileId}?error=${encodeURIComponent(
        "Foto nicht gefunden"
      )}`
    );
  }

  await supabase.storage.from("customer-photos").remove([row.storage_path]);
  await supabase.from("customer_photos").delete().eq("id", photoId);

  redirect(`/customers/${customerProfileId}`);
}