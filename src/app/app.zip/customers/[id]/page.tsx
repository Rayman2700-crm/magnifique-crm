import Link from "next/link";
import { supabaseServer } from "@/lib/supabase/server";
import { addCustomerNote, deleteCustomerPhoto } from "./actions";
import PhotoUpload from "./PhotoUpload";

type Person = {
  id: string;
  full_name: string | null;
  phone: string | null;
  email: string | null;
  birthday: string | null;
};

type NoteRow = {
  id: string;
  note: string;
  created_at: string;
  updated_at: string;
  created_by: string;
};

type PhotoRow = {
  id: string;
  storage_path: string;
  original_name: string | null;
  mime_type: string | null;
  size_bytes: number | null;
  created_at: string;
};

export default async function CustomerDetailPage({
  params,
  searchParams,
}: {
  params: { id: string } | Promise<{ id: string }>;
  searchParams?: { error?: string } | Promise<{ error?: string }>;
}) {
  const p = await params;
  const customerProfileId = p.id;

  const sp = searchParams ? await searchParams : undefined;

  const supabase = await supabaseServer();

  // Customer profile + person
  const { data, error } = await supabase
    .from("customer_profiles")
    .select(
      `
      id,
      created_at,
      person:persons (
        id,
        full_name,
        phone,
        email,
        birthday
      )
    `
    )
    .eq("id", customerProfileId)
    .single();

  if (error || !data) {
    return (
      <main className="p-6 max-w-3xl mx-auto">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-semibold">Kunde nicht gefunden</h1>
          <Link className="rounded-xl border px-3 py-2" href="/customers">
            Zurück
          </Link>
        </div>

        <div className="mt-6 rounded-2xl border border-red-300 bg-red-50 p-4 text-sm text-red-700">
          <div className="font-semibold">DB-Fehler / keine Daten</div>
          <div className="mt-2">
            <strong>ID:</strong> {customerProfileId}
          </div>
          <div className="mt-2">
            <strong>Error:</strong> {error?.message ?? "no data returned"}
          </div>
        </div>
      </main>
    );
  }

  const person = (data as any).person as Person | null;

  // Notes
  const { data: notes, error: notesError } = await supabase
    .from("customer_notes")
    .select("id, note, created_at, updated_at, created_by")
    .eq("customer_profile_id", customerProfileId)
    .order("created_at", { ascending: false });

  const notesRows = (notes ?? []) as NoteRow[];

  // Photos
  const { data: photos, error: photosError } = await supabase
    .from("customer_photos")
    .select("id, storage_path, original_name, mime_type, size_bytes, created_at")
    .eq("customer_profile_id", customerProfileId)
    .order("created_at", { ascending: false });

  const photoRows = (photos ?? []) as PhotoRow[];

  // Signed URLs (privater Bucket)
  const signedUrls: Record<string, string> = {};
  for (const ph of photoRows) {
    const { data: signed } = await supabase.storage
      .from("customer-photos")
      .createSignedUrl(ph.storage_path, 60 * 60); // 1h

    if (signed?.signedUrl) signedUrls[ph.id] = signed.signedUrl;
  }

  return (
    <main className="p-6 max-w-5xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">
            {person?.full_name ?? "Unbekannt"}
          </h1>
          <p className="text-sm text-gray-500">
            Kundendetail ({customerProfileId})
          </p>
        </div>

        <Link className="rounded-xl border px-3 py-2" href="/customers">
          Zurück
        </Link>
      </div>

      {sp?.error && (
        <div className="mt-4 rounded-xl border border-red-300 bg-red-50 p-3 text-sm text-red-700">
          {decodeURIComponent(sp.error)}
        </div>
      )}

      <div className="mt-6 rounded-2xl border p-4 space-y-2">
        <div>
          <strong>Telefon:</strong> {person?.phone ?? "-"}
        </div>
        <div>
          <strong>E-Mail:</strong> {person?.email ?? "-"}
        </div>
        <div>
          <strong>Geburtsdatum:</strong>{" "}
          {person?.birthday ? new Date(person.birthday).toLocaleDateString() : "-"}
        </div>
        <div>
          <strong>Erstellt:</strong>{" "}
          {data.created_at ? new Date(data.created_at).toLocaleDateString() : "-"}
        </div>
      </div>

      {/* 15.3.1 – Fragebogen starten */}
      <div className="mt-6">
        <Link
          href={`/customers/${customerProfileId}/forms/new`}
          className="inline-block rounded-xl bg-black text-white px-4 py-2"
        >
          Fragebogen starten
        </Link>
      </div>

      {/* NOTIZEN */}
      <section className="mt-8">
        <h2 className="text-lg font-semibold">Notizen</h2>

        {notesError && (
          <div className="mt-3 rounded-xl border border-red-300 bg-red-50 p-3 text-sm text-red-700">
            Notizen Fehler: {notesError.message}
          </div>
        )}

        <form
          className="mt-4 space-y-2"
          action={addCustomerNote.bind(null, customerProfileId)}
        >
          <label className="text-sm font-medium">Neue Notiz</label>
          <textarea
            name="note"
            className="w-full rounded-xl border px-3 py-2 min-h-[110px]"
            placeholder="Notiz eingeben..."
          />
          <button className="rounded-xl bg-black text-white px-4 py-2">
            Notiz speichern
          </button>
        </form>

        <div className="mt-6 space-y-3">
          {notesRows.length === 0 ? (
            <div className="text-sm text-gray-500">Noch keine Notizen.</div>
          ) : (
            notesRows.map((n) => (
              <div key={n.id} className="rounded-2xl border p-4">
                <div className="text-sm whitespace-pre-wrap">{n.note}</div>
                <div className="mt-2 text-xs text-gray-500">
                  Erstellt: {n.created_at ? new Date(n.created_at).toLocaleString() : "-"}
                  {n.updated_at && n.updated_at !== n.created_at
                    ? ` • Bearbeitet: ${new Date(n.updated_at).toLocaleString()}`
                    : ""}
                </div>
              </div>
            ))
          )}
        </div>
      </section>

      {/* FOTOS */}
      <section className="mt-10">
        <h2 className="text-lg font-semibold">Fotos</h2>

        {photosError && (
          <div className="mt-3 rounded-xl border border-red-300 bg-red-50 p-3 text-sm text-red-700">
            Fotos Fehler: {photosError.message}
          </div>
        )}

        {/* Upload + Komprimierung (Client) */}
        <div className="mt-4">
          <PhotoUpload customerProfileId={customerProfileId} />
        </div>

        {/* Galerie: kleine Thumbnails + Klick öffnet groß */}
        <div className="mt-6">
          {photoRows.length === 0 ? (
            <div className="text-sm text-gray-500">Noch keine Fotos.</div>
          ) : (
            <div className="flex flex-wrap gap-3">
              {photoRows.map((ph) => {
                const url = signedUrls[ph.id];

                return (
                  <div
                    key={ph.id}
                    className="rounded-xl border overflow-hidden"
                    style={{ width: 180 }}
                  >
                    <div className="bg-gray-100" style={{ width: 180, height: 120 }}>
                      {url ? (
                        <a href={url} target="_blank" rel="noreferrer">
                          {/* eslint-disable-next-line @next/next/no-img-element */}
                          <img
                            src={url}
                            alt={ph.original_name ?? "Foto"}
                            className="w-full h-full object-cover"
                            loading="lazy"
                          />
                        </a>
                      ) : (
                        <div className="text-xs text-gray-500 p-3">
                          Kein Zugriff / URL nicht verfügbar
                        </div>
                      )}
                    </div>

                    <div className="p-2 text-xs text-gray-600">
                      <div className="font-medium text-black truncate">
                        {ph.original_name ?? "Foto"}
                      </div>
                      <div className="mt-1">
                        {ph.created_at ? new Date(ph.created_at).toLocaleString() : "-"}
                        {ph.size_bytes ? ` • ${Math.round(ph.size_bytes / 1024)} KB` : ""}
                      </div>

                      <div className="mt-2 flex items-center justify-between">
                        {url ? (
                          <a
                            className="rounded-lg border px-2 py-1"
                            href={url}
                            target="_blank"
                            rel="noreferrer"
                          >
                            Groß öffnen
                          </a>
                        ) : (
                          <span className="text-gray-400">—</span>
                        )}

                        <form
                          action={deleteCustomerPhoto.bind(null, customerProfileId, ph.id)}
                        >
                          <button className="rounded-lg border px-2 py-1">Löschen</button>
                        </form>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </section>
    </main>
  );
}