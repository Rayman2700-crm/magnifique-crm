"use server";

import { redirect } from "next/navigation";
import { supabaseServer } from "@/lib/supabase/server";

export async function startIntakeForm(
  customerProfileId: string,
  formData: FormData
) {
  const templateId = String(formData.get("template_id") ?? "").trim();
  if (!templateId) {
    redirect(
      `/customers/${customerProfileId}/forms/new?error=${encodeURIComponent(
        "Kein Template gewählt"
      )}`
    );
  }

  const supabase = await supabaseServer();

  const { data: userData } = await supabase.auth.getUser();
  const user = userData.user;
  if (!user) redirect("/login");

  const { data: profile, error: profileError } = await supabase
    .from("user_profiles")
    .select("tenant_id, role")
    .eq("user_id", user.id)
    .single();

  if (profileError || !profile) {
    redirect(
      `/customers/${customerProfileId}/forms/new?error=${encodeURIComponent(
        "Kein Benutzerprofil gefunden"
      )}`
    );
  }

  // Tenant bestimmen:
  // Practitioner: eigener tenant_id
  // Admin: tenant vom Kundenprofil
  let tenantId: string | null = profile.tenant_id ?? null;

  if (profile.role === "ADMIN") {
    const { data: cp, error: cpError } = await supabase
      .from("customer_profiles")
      .select("tenant_id")
      .eq("id", customerProfileId)
      .single();

    if (cpError || !cp?.tenant_id) {
      redirect(
        `/customers/${customerProfileId}/forms/new?error=${encodeURIComponent(
          "Konnte Tenant des Kunden nicht laden"
        )}`
      );
    }
    tenantId = cp.tenant_id;
  }

  if (!tenantId) {
    redirect(
      `/customers/${customerProfileId}/forms/new?error=${encodeURIComponent(
        "Kein Tenant gefunden"
      )}`
    );
  }

  // Template holen (für snapshot)
  const { data: tpl, error: tplErr } = await supabase
    .from("form_templates")
    .select("id, tenant_id, name, version, schema_json, is_active")
    .eq("id", templateId)
    .single();

  if (tplErr || !tpl) {
    redirect(
      `/customers/${customerProfileId}/forms/new?error=${encodeURIComponent(
        "Template nicht gefunden"
      )}`
    );
  }

  if (tpl.tenant_id !== tenantId) {
    redirect(
      `/customers/${customerProfileId}/forms/new?error=${encodeURIComponent(
        "Template gehört nicht zu diesem Tenant"
      )}`
    );
  }

  if (!tpl.is_active) {
    redirect(
      `/customers/${customerProfileId}/forms/new?error=${encodeURIComponent(
        "Template ist nicht aktiv"
      )}`
    );
  }

  // Intake Form anlegen
  const { data: inserted, error: insErr } = await supabase
    .from("intake_forms")
    .insert({
      tenant_id: tenantId,
      customer_profile_id: customerProfileId,
      template_id: tpl.id,
      template_version: tpl.version,
      schema_json: tpl.schema_json, // snapshot
      answers_json: {}, // leer
      status: "DRAFT",
      created_by: user.id,
    })
    .select("id")
    .single();

  if (insErr || !inserted?.id) {
    redirect(
      `/customers/${customerProfileId}/forms/new?error=${encodeURIComponent(
        `Konnte Formular nicht erstellen: ${insErr?.message ?? "unknown"}`
      )}`
    );
  }

  // Nächster Schritt: Formular ausfüllen Seite
  redirect(`/customers/${customerProfileId}/forms/${inserted.id}`);
}