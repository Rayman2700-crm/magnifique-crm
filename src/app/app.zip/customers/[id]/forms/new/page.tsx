import Link from "next/link";
import { supabaseServer } from "@/lib/supabase/server";
import { startIntakeForm } from "./actions";

type TemplateRow = {
  id: string;
  name: string;
  version: number;
  created_at: string;
  is_active: boolean;
};

export default async function NewIntakeFormPage({
  params,
  searchParams,
}: {
  params: { id: string } | Promise<{ id: string }>;
  searchParams?: { error?: string } | Promise<{ error?: string }>;
}) {
  const p = await params;
  const customerProfileId = p.id;

  const sp = searchParams ? await searchParams : undefined;

  const supabase = await supabaseServer();

  const { data: userData } = await supabase.auth.getUser();
  const user = userData.user;
  if (!user) {
    return (
      <main className="p-6 max-w-3xl mx-auto">
        <div className="rounded-xl border p-4">Bitte einloggen.</div>
      </main>
    );
  }

  // tenant bestimmen (wie bei notes/photos)
  const { data: profile } = await supabase
    .from("user_profiles")
    .select("tenant_id, role")
    .eq("user_id", user.id)
    .single();

  let tenantId: string | null = profile?.tenant_id ?? null;

  if (profile?.role === "ADMIN") {
    const { data: cp } = await supabase
      .from("customer_profiles")
      .select("tenant_id")
      .eq("id", customerProfileId)
      .single();
    tenantId = cp?.tenant_id ?? null;
  }

  if (!tenantId) {
    return (
      <main className="p-6 max-w-3xl mx-auto">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-semibold">Fragebogen starten</h1>
          <Link className="rounded-xl border px-3 py-2" href={`/customers/${customerProfileId}`}>
            Zurück
          </Link>
        </div>

        <div className="mt-6 rounded-2xl border border-red-300 bg-red-50 p-4 text-sm text-red-700">
          Kein Tenant gefunden (Admin muss später Tenant wählen – aktuell wird Tenant vom Kundenprofil gezogen).
        </div>
      </main>
    );
  }

  // aktive Templates des Tenants laden
  const { data: templates, error } = await supabase
    .from("form_templates")
    .select("id, name, version, created_at, is_active")
    .eq("tenant_id", tenantId)
    .eq("is_active", true)
    .order("created_at", { ascending: false });

  const rows = (templates ?? []) as TemplateRow[];

  return (
    <main className="p-6 max-w-3xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Fragebogen starten</h1>
          <p className="text-sm text-gray-500">
            Wähle eine Formularvorlage und starte den Fragebogen.
          </p>
        </div>

        <Link className="rounded-xl border px-3 py-2" href={`/customers/${customerProfileId}`}>
          Zurück
        </Link>
      </div>

      {sp?.error && (
        <div className="mt-4 rounded-xl border border-red-300 bg-red-50 p-3 text-sm text-red-700">
          {decodeURIComponent(sp.error)}
        </div>
      )}

      {error && (
        <div className="mt-4 rounded-xl border border-red-300 bg-red-50 p-3 text-sm text-red-700">
          Fehler beim Laden der Templates: {error.message}
        </div>
      )}

      <div className="mt-6 rounded-2xl border p-4">
        {rows.length === 0 ? (
          <div className="text-sm text-gray-500">
            Keine aktiven Form Templates gefunden (form_templates).
          </div>
        ) : (
          <form action={startIntakeForm.bind(null, customerProfileId)} className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Vorlage</label>
              <select
                name="template_id"
                className="w-full rounded-xl border px-3 py-2"
                defaultValue={rows[0].id}
              >
                {rows.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name} (v{t.version})
                  </option>
                ))}
              </select>
              <div className="text-xs text-gray-500">
                Es wird ein Snapshot des Schemas in <code>intake_forms.schema_json</code> gespeichert.
              </div>
            </div>

            <button className="rounded-xl bg-black text-white px-4 py-2">
              Starten
            </button>
          </form>
        )}
      </div>
    </main>
  );
}