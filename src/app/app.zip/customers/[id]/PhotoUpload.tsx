"use client";

import { useState, useTransition } from "react";
import { uploadCustomerPhotos } from "./actions";

async function compressImageToJpeg(file: File, maxSize = 1600, quality = 0.8) {
  if (!file.type.startsWith("image/")) return file;

  const img = document.createElement("img");
  const url = URL.createObjectURL(file);

  try {
    await new Promise<void>((resolve, reject) => {
      img.onload = () => resolve();
      img.onerror = () => reject(new Error("Bild konnte nicht geladen werden"));
      img.src = url;
    });

    const w = img.naturalWidth;
    const h = img.naturalHeight;

    const scale = Math.min(1, maxSize / Math.max(w, h));
    const nw = Math.round(w * scale);
    const nh = Math.round(h * scale);

    const canvas = document.createElement("canvas");
    canvas.width = nw;
    canvas.height = nh;

    const ctx = canvas.getContext("2d");
    if (!ctx) return file;

    ctx.drawImage(img, 0, 0, nw, nh);

    const blob: Blob = await new Promise((resolve) =>
      canvas.toBlob((b) => resolve(b as Blob), "image/jpeg", quality)
    );

    const newName = file.name.replace(/\.[^/.]+$/, "") + "_compressed.jpg";
    return new File([blob], newName, { type: "image/jpeg" });
  } finally {
    URL.revokeObjectURL(url);
  }
}

export default function PhotoUpload({
  customerProfileId,
}: {
  customerProfileId: string;
}) {
  const [files, setFiles] = useState<File[]>([]);
  const [info, setInfo] = useState<string>("");
  const [isPending, startTransition] = useTransition();

  return (
    <div className="rounded-2xl border p-4">
      <div className="font-semibold">Fotos hinzufügen</div>
      <p className="text-sm text-gray-500 mt-1">
        Du kannst mehrere Fotos auswählen. Bilder werden automatisch komprimiert
        (spart Speicher).
      </p>

      <div className="mt-3 flex items-center gap-3">
        <input
          type="file"
          accept="image/*"
          multiple
          className="rounded-xl border px-3 py-2"
          onChange={async (e) => {
            const list = Array.from(e.target.files ?? []);
            if (list.length === 0) {
              setFiles([]);
              setInfo("");
              return;
            }

            setInfo(`Komprimiere ${list.length} Bild(er)...`);

            const out: File[] = [];
            let skipped = 0;

            for (const f of list) {
              try {
                const compressed = await compressImageToJpeg(f);
                out.push(compressed);
              } catch {
                out.push(f);
                skipped++;
              }
            }

            setFiles(out);

            const kbOld = Math.round(
              list.reduce((s, f) => s + f.size, 0) / 1024
            );
            const kbNew = Math.round(
              out.reduce((s, f) => s + f.size, 0) / 1024
            );

            setInfo(
              `Bereit: ${list.length} Datei(en) • ${kbOld} KB → ${kbNew} KB` +
                (skipped ? ` • ${skipped} ohne Komprimierung` : "")
            );
          }}
        />

        <button
          className="rounded-xl bg-black text-white px-4 py-2 disabled:opacity-50"
          disabled={files.length === 0 || isPending}
          onClick={() => {
            if (files.length === 0) return;

            startTransition(async () => {
              const fd = new FormData();
              for (const f of files) fd.append("photos", f);
              await uploadCustomerPhotos(customerProfileId, fd);
              // redirect passiert serverseitig in der Action
            });
          }}
        >
          {isPending ? "Upload..." : "Upload"}
        </button>
      </div>

      {info && <div className="mt-2 text-xs text-gray-500">{info}</div>}
      {files.length > 0 && (
        <div className="mt-2 text-xs text-gray-500">
          Ausgewählt: {files.length} Datei(en)
        </div>
      )}
    </div>
  );
}